package com.pranjal.splashscreen;

class ModelChatList {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ModelChatList() {
    }

    public ModelChatList(String id) {
        this.id = id;
    }

    String id;
}
